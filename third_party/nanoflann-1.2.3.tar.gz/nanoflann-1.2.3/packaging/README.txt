This directory contains the scripts I've been using to maintain Debian, Ubuntu and Fedora 
packages for MRPT. They should NOT appear in source tarballs (that's the rule according 
to Debian policies) but I'll keep them in SVN HEAD. 

JL

